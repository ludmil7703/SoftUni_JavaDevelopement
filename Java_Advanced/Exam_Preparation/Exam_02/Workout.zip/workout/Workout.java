package workout;


import java.util.ArrayList;
import java.util.List;

public class Workout {
    private List<Exercise> exercises;
    private String type;
    private int exerciseCount;

    public Workout(String type, int exerciseCount) {
        this.type = type;
        this.exerciseCount = exerciseCount;
        this.exercises = new ArrayList<>();
    }
    public void addExercise (Exercise exercise){
        if (this.exercises.size() < this.exerciseCount){
            this.exercises.add(exercise);
        }
    }
    public boolean removeExercise (String name, String muscle){
        for (Exercise exercise : this.exercises) {
            if (exercise.getName().equals(name) && exercise.getMuscle().equals(muscle)){
                this.exercises.remove(exercise);
                return true;
            }
        }
        return false;
    }
    public Exercise getExercise (String name, String muscle){
        for (Exercise exercise : exercises) {
            if (exercise.getName().equals(name) && exercise.getMuscle().equals(muscle)){
                return exercise;
            }
        }
        return null;
    }
    public Exercise getMostBurnedCaloriesExercise() {
        Exercise exercise = null;
        int calories = 0;

        if (this.exercises.size() > 0) {
            for (Exercise ex : this.exercises) {
                if (ex.getBurnedCalories() > calories) {
                    calories = ex.getBurnedCalories();
                }
            }
            for (Exercise ex : this.exercises) {
                if (ex.getBurnedCalories() == calories) {
                    exercise = ex;
                    break;
                }
            }
        }
        return exercise;
    }

    public int getExerciseCount() {
        return exerciseCount;
    }
    public String getStatistics(){
        StringBuilder sB = new StringBuilder();
        sB.append(String.format("Workout type: %s", this.type));
        sB.append(System.lineSeparator());
        for (Exercise exercise : exercises) {
            sB.append(exercise);
            sB.append(System.lineSeparator());
        }
        return sB.toString().trim();
    }
}
