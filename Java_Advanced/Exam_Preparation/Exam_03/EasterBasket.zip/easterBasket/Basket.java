package easterBasket;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Basket {
    private List<Egg> data;
    private String material;
    private int capacity;

    public Basket(String material, int capacity){
        this.material = material;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }
    public void addEgg(Egg egg){
        if (data.size() < this.capacity){
            data.add(egg);
        }
    }
    public boolean removeEgg(String color){
        Egg eggToRemove = data.stream().filter(e-> e.getColor().equals(color)).findFirst().orElse(null);
        if (eggToRemove != null){
            data.remove(eggToRemove);
            return true;
        }
        return false;
    }
    public Egg getStrongestEgg(){
        return data.stream().max(Comparator.comparing(Egg::getStrength)).get();
    }
    public Egg getEgg(String color){
        return data.stream().filter(e-> e.getColor().equals(color)).findFirst().get();
    }
    public int getCount(){
        return this.data.size();
    }
    public String report(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s basket contains:%n", this.material));
        for (Egg egg : data) {
            sb.append(egg).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
