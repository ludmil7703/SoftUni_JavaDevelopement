package parrots;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Cage {
    private String name;
    private int capacity;
    private List<Parrot> data;

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }
    public void add (Parrot parrot){
        if (this.data.size() < this.capacity){
            this.data.add(parrot);
        }
    }
    public boolean remove (String name){
        for (Parrot parrot : this.data) {
            if (parrot.getName().equals(name)){
                this.data.remove(parrot);
                return true;
            }
        }
        return false;
    }
    public Parrot sellParrot (String name){
        data.stream().filter(e-> e.getName().equals(name)).findFirst().get().setAvailable(false);
        return data.stream().filter(e-> e.getName().equals(name)).findFirst().orElse(null);

    }
    public List<Parrot> sellParrotBySpecies (String species){
        List<Parrot> sellBySpecies = new ArrayList<>();
     sellBySpecies = data.stream().filter(e-> e.getSpecies().equals(species)).collect(Collectors.toList());
     this.data = this.data.stream().filter(e-> !e.getSpecies().equals(species)).collect(Collectors.toList());
               return sellBySpecies;
    }
    public int count(){
        return this.data.size();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }


    public String report() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("Parrots available at %s:", this.name)).append(System.lineSeparator());
        for (Parrot parrot : data) {
            if (parrot.isAvailable()){
                sb.append(parrot).append(System.lineSeparator());
            }
        }
        return sb.toString().trim();
    }
}
