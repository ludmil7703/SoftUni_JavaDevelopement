package BankAccount;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Map<Integer, BankAccount> customers = new HashMap();

        String input = scanner.nextLine();

        while (!input.equals("End")){
            String[] commandParts = input.split("\\s+");
            String command = commandParts[0];
            switch (command){
                case "Create":
                    BankAccount bankAccount = new BankAccount();
                    customers.put(bankAccount.getId(), bankAccount);
                    System.out.println("Account ID" +bankAccount.getId() + " created");
                    break;
                case "Deposit":
                    int id =Integer.parseInt(commandParts[1]);
                    int amount = Integer.parseInt(commandParts[2]);
                    bankAccount = customers.get(id);
                    if (customers.containsKey(id)) {

                        bankAccount.deposit(amount);
                        System.out.printf("Deposited %d to ID%d%n", amount, bankAccount.getId());
                    } else {
                        System.out.println("Account does not exist");
                    }
                    break;
                case "SetInterest":
                    double interestRate = Double.parseDouble(commandParts[1]);
                    BankAccount.setInterest(interestRate);

                    break;
                case "GetInterest":
                   id = Integer.parseInt(commandParts[1]);
                   int years = Integer.parseInt(commandParts[2]);
                   bankAccount = customers.get(id);
                   if (customers.containsKey(id)) {
                       System.out.printf("%.2f%n", bankAccount.getInterest(years));
                   } else {
                       System.out.println("Account does not exist");
                   }
                    break;
                default:break;
            }
            input = scanner.nextLine();
        }
       
    }
}
