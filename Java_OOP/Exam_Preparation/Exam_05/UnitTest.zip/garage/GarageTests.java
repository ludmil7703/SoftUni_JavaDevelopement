package garage;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class GarageTests {
    @Test
    public void testAddCarSuccessfully() {
        Car car = new Car("Lada", 150, 150.20);
        Garage garage = new Garage();
        garage.addCar(car);
        Assert.assertEquals("Lada", car.getBrand());
        Assert.assertEquals(150, car.getMaxSpeed());
        Assert.assertEquals(150.20, car.getPrice(), 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarWithNullArgument() {
        Garage garage = new Garage();
        garage.addCar(null);
    }

    @Test
    public void testGetCarsAndGetCount() {
        Car car = new Car("Lada", 150, 150.20);
        Car car1 = new Car("Moskvich", 160, 200);
        Garage garage = new Garage();
        garage.addCar(car);
        garage.addCar(car1);
        Assert.assertEquals(garage.getCars().get(0).getBrand(), "Lada");
        Assert.assertEquals(garage.getCars().get(1).getBrand(), "Moskvich");
        Assert.assertEquals(garage.getCount(), 2);
    }

    @Test
    public void testFindAllCarsWithMaxSpeedAbove() {
        Car car = new Car("Lada", 150, 150.20);
        Car car1 = new Car("Moskvich", 160, 200);
        Garage garage = new Garage();
        garage.addCar(car);
        garage.addCar(car1);
        List<Car> cars = garage.findAllCarsWithMaxSpeedAbove(150);
        Assert.assertEquals(cars.get(0).getMaxSpeed(), 160);
    }

    @Test
    public void testGetTheMostExpensive() {
        Car car = new Car("Lada", 150, 150.20);
        Car car1 = new Car("Moskvich", 160, 200);
        Garage garage = new Garage();
        garage.addCar(car);
        garage.addCar(car1);
        Car mostExpensiveCar = garage.getTheMostExpensiveCar();
        Assert.assertEquals(mostExpensiveCar.getPrice(), 200, 0);

    }

    @Test
    public void testFindAllCarsByBrand() {
        Car car = new Car("Lada", 150, 150.20);
        Car car1 = new Car("Moskvich", 160, 200);
        Garage garage = new Garage();
        garage.addCar(car);
        garage.addCar(car1);
        List<Car> cars = garage.findAllCarsByBrand("Lada");
        Assert.assertEquals(cars.get(0).getBrand(), "Lada");
    }
}