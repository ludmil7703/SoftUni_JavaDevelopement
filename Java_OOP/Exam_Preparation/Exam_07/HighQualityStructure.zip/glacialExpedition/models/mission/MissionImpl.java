package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;

import java.util.Collection;

public class MissionImpl implements Mission{
    public MissionImpl() {
    }

    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        for (Explorer explorer : explorers) {
            if (explorer.canSearch()){
                for (String exhibit : state.getExhibits()) {
                    explorer.getSuitcase().getExhibits().add(exhibit);
                    explorer.search();
                    state.getExhibits().remove(exhibit);
                    if (!explorer.canSearch()){
                        break;
                    }
                }
            }
        }
    }
}
