package farmville;

import org.junit.Assert;
import org.junit.Test;

public class FarmvilleTests {
  @Test
    public void testConstructorCorrect(){
      Farm farm = new Farm("Pesho", 2);
      Assert.assertEquals(farm.getName(), "Pesho");
      Assert.assertEquals(farm.getCapacity(), 2);
  }
  @Test
    public void testGetCount(){
      Farm farm = new Farm("Pesho", 2);
      Animal animal = new Animal("Koko", 10);
      farm.add(animal);
      Assert.assertEquals(farm.getCount(), 1);
      Assert.assertEquals(animal.getEnergy(), 10, 0);
  }
  @Test(expected = IllegalArgumentException.class)
    public void testAddAnimalWithFullFarm(){
      Farm farm = new Farm("Pesho", 1);
      Animal animal = new Animal("Koko", 10);
      Animal animal1 = new Animal("Koko1", 10);
      farm.add(animal);
      farm.add(animal1);

  }
    @Test(expected = IllegalArgumentException.class)
    public void testAddAnimalWithExistingAnimal(){
        Farm farm = new Farm("Pesho", 2);
        Animal animal = new Animal("Koko", 10);
        farm.add(animal);
        farm.add(animal);

    }
    @Test
    public void testRemove(){
            Farm farm = new Farm("Pesho", 3);
            Animal animal = new Animal("Koko", 10);
            Animal animal1 = new Animal("Koko1", 10);
            farm.add(animal);
            farm.add(animal1);
            farm.remove("Koko");
            Assert.assertEquals(farm.getCount(), 1);

    }
    @Test
    public void testRemoveNotExist(){
        Farm farm = new Farm("Pesho", 3);
        Assert.assertFalse(farm.remove(null));

    }
    @Test(expected = NullPointerException.class)
    public void testWithNullName(){
      Farm farm = new Farm(null, 2);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testWithNegativeCapacity(){
      Farm farm = new Farm("Pesho", -5);
    }

}
