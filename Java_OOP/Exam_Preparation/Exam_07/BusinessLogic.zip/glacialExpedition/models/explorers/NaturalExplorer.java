package glacialExpedition.models.explorers;

public class NaturalExplorer extends BaseExplorer{
    private static final double NATURAL_EXPLORER_INITIAL_ENERGY = 60;
    public NaturalExplorer(String name) {
        super(name, NATURAL_EXPLORER_INITIAL_ENERGY);
    }
    @Override
    public void search() {
        if (getEnergy() - 7 < 0){
            super.setEnergy(0);
        } else {
            super.setEnergy(getEnergy() - 7);
        }
    }
}
