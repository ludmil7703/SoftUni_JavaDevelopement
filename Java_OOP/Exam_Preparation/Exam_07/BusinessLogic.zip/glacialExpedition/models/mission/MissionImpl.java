package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class MissionImpl implements Mission{
    public MissionImpl() {
    }

    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        ArrayDeque<Explorer> explorerDeque = explorers.stream().filter(e -> e.getEnergy() > 0).collect(Collectors.toCollection(ArrayDeque::new));
        ArrayDeque<String> exhibits = new ArrayDeque<>(state.getExhibits());
        while (!explorerDeque.isEmpty() && !exhibits.isEmpty()){
            Explorer explorer = explorerDeque.peek();
            while (explorer.canSearch() && !exhibits.isEmpty()){
                String currentExhibit = exhibits.peek();
                explorer.search();
                explorer.getSuitcase().getExhibits().add(currentExhibit);
                state.getExhibits().remove(currentExhibit);
                exhibits.pop();

            }
            explorerDeque.pop();
        }

    }
}
