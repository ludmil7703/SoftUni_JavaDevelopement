package glacialExpedition.repositories;

import glacialExpedition.models.states.State;

import java.util.*;

public class StateRepository implements Repository<State> {
    private Map<String, State> states;

    public StateRepository() {
        this.states = new LinkedHashMap<>();
    }

    @Override
    public Collection<State> getCollection() {
        return Collections.unmodifiableCollection(this.states.values());
    }

    @Override
    public void add(State state) {
        this.states.putIfAbsent(state.getName(), state);
    }

    @Override
    public boolean remove(State state) {
        return this.states.remove(state.getName()) != null;
    }

    @Override
    public State byName(String name) {
        return states.values().stream().filter(s-> s.getName().equals(name)).findFirst().orElse(null);
    }
}
