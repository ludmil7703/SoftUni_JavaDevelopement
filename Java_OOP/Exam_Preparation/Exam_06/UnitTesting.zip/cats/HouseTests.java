package cats;

import org.junit.Assert;
import org.junit.Test;

public class HouseTests {
    private House house;
    @Test(expected = IllegalArgumentException.class)
    public void testCreateHouseWithInvalidCapacity(){
        house = new House("House1", -4);
    }
    @Test(expected = NullPointerException.class)
    public void testCreateHouseWithInvalidName(){
         house = new House(null, 5);
    }
    @Test(expected = NullPointerException.class)
    public void testCreateHouseWithInvalidNameEmpty(){
       house =  new House("", 5);
    }
    @Test
    public void testCreateHouseWithValidNameAndCapacity(){
        house = new House("House1", 4);
        Assert.assertEquals("House1", house.getName());
        Assert.assertEquals(4, house.getCapacity());
    }
    @Test
    public void testAddCat(){
        house = new House("House1", 10);
        Cat mike = new Cat("Mike");
        Assert.assertEquals(0, house.getCount());
        house.addCat(mike);
        Assert.assertEquals(1, house.getCount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddCatWithFullHouse(){
        house = new House("House1", 1);
        Cat mike = new Cat("Mike");
        house.addCat(mike);
        Cat betty = new Cat("Betty");
        house.addCat(betty);
    }
    @Test
    public void testRemoveCat(){
        house = new House("House1", 10);
        Cat mike = new Cat("Mike");
        Cat betty = new Cat("Betty");
        house.addCat(mike);
        house.addCat(betty);
        Assert.assertEquals(2, house.getCount());
        house.removeCat("Betty");
        Assert.assertEquals(1, house.getCount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testRemoveCatWithNoName(){
        house = new House("House1", 10);
        Cat mike = new Cat("Mike");
       house.addCat(mike);
       house.removeCat("Betty");
    }
    @Test
    public void testCatForSale() {
        house = new House("House1", 10);
        Cat mike = new Cat("Mike");
        house.addCat(mike);
       Cat returnedCat =  house.catForSale("Mike");
       Assert.assertFalse(returnedCat.isHungry());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testCatForSaleWithNoName(){
        house = new House("House1", 10);
        house.catForSale("Ivan");
    }
    @Test
    public void testStatistics(){
        house = new House("House1", 10);
        Cat mike = new Cat("Mike");
        Cat betty = new Cat("Betty");
        house.addCat(mike);
        house.addCat(betty);
        Assert.assertEquals("The cat Mike, Betty is in the house House1!",
                house.statistics());
    }


}
