package football.entities.player;

public class Men extends BasePlayer{
    private static final double INITIAL_KILOGRAM = 85.50;
    private static final int INCREASE_STRENGTH = 145;

    public Men(String name, String nationality, int strength) {
        super(name, nationality, INITIAL_KILOGRAM, strength);
    }

    @Override
    public void stimulation() {
        setStrength(getStrength() + INCREASE_STRENGTH);
    }

    @Override
    public double getKg() {
        return INITIAL_KILOGRAM;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getStrength() {
        return super.getStrength();
    }
}
