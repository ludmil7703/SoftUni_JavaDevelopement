package football.entities.player;

public class Women extends BasePlayer{
    private static final double INITIAL_KILOGRAM = 60.00;
    private static final int INCREASE_STRENGTH = 115;

    public Women(String name, String nationality, int strength) {
        super(name, nationality, INITIAL_KILOGRAM, strength);
    }

    @Override
    public void stimulation() {
        setStrength(getStrength() + INCREASE_STRENGTH);
    }

    @Override
    public double getKg() {
        return INITIAL_KILOGRAM;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getStrength() {
        return super.getStrength();
    }
}
