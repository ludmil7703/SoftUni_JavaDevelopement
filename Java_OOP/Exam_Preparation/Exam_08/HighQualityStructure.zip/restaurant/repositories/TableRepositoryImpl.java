package restaurant.repositories;

import restaurant.entities.tables.interfaces.Table;
import restaurant.repositories.interfaces.TableRepository;

import java.util.Collection;

public class TableRepositoryImpl implements TableRepository<Table> {
    private Collection<Table> tables;
    @Override
    public Collection<Table> getAllEntities() {
        return this.tables;
    }

    @Override
    public void add(Table table) {
        this.tables.add(table);
    }

    @Override
    public Table byNumber(int number) {
        return this.tables.stream().filter(t-> t.getTableNumber() == number).findFirst().orElse(null);
    }
}
