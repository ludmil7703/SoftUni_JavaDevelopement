package shopAndGoods;


import org.junit.Assert;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class ShopTest {
    @Test
    public void testAddCorrect() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves12", goods);
        Assert.assertEquals(goods.getName(), "Printer");
        Assert.assertEquals(shop.getShelves().get("Shelves12").getGoodsCode(), "11");
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddGoodTHR() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves13", goods);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddGoodThrowWithTakenShelves() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves12", goods);
        shop.addGoods("Shelves12", goods);
    }
    @Test(expected = OperationNotSupportedException.class)
    public void testAddGoodsWithOperationNotSupport() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves1", goods);
        shop.addGoods("Shelves2", goods);
    }
    @Test(expected = IllegalArgumentException.class)
    public void removeGoodsWithIllegalArgumentException() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.removeGoods("Shelves13", goods);

    }
    @Test(expected = IllegalArgumentException.class)
    public void testRemoveGoodsWithException() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves12", goods);
        shop.removeGoods("Shelves11", goods);
    }
    @Test
    public void testRemoveCorrect() throws OperationNotSupportedException {
        Shop shop = new Shop();
        Goods goods = new Goods("Printer", "11");
        shop.addGoods("Shelves12", goods);
        Assert.assertEquals(shop.removeGoods("Shelves12", goods),
                "Goods: 11 is removed successfully!");
    }
}