package spaceStation.models.astronauts;

public class Meteorologist extends BaseAstronaut{
    private final static double METEOROLOGIST_INITIAL_OXYGEN = 90;
    public Meteorologist(String name) {
        super(name, METEOROLOGIST_INITIAL_OXYGEN);
    }
}
