package spaceStation.models.mission;

import spaceStation.models.astronauts.Astronaut;
import spaceStation.models.planets.Planet;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class MissionImpl implements Mission{
    public MissionImpl() {
    }

    @Override
    public void explore(Planet planet, Collection<Astronaut> astronauts) {
        ArrayDeque<Astronaut> astronautsToExplore = astronauts.stream().filter(Astronaut::canBreath).collect(Collectors.toCollection(ArrayDeque::new));
        ArrayDeque<String> items = new ArrayDeque<>(planet.getItems());
        while (astronautsToExplore.isEmpty() || items.isEmpty()){
            Astronaut astronaut = astronautsToExplore.peek();
            while (astronaut.canBreath() || items.isEmpty()){
                String currentItem = items.pop();
                astronaut.breath();
                astronaut.getBag().getItems().add(currentItem);
            }
            astronautsToExplore.pop();
        }
    }
}
