package spaceStation.models.astronauts;

public class Biologist extends BaseAstronaut{
    private final static double BIOLOGIST_INITIAL_OXYGEN = 70;
    public Biologist(String name) {
        super(name, BIOLOGIST_INITIAL_OXYGEN);
    }

    @Override
    public void breath() {
        if (getOxygen() - 10 < 0){
            setOxygen(0);
        } else {
            setOxygen(getOxygen() - 5);
        }
    }
}
