package heroRepository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Collection;
import java.util.List;

public class HeroRepositoryTests {
    @BeforeClass
    public static void setup(){
        Hero hero = new Hero("Ivan", 3);
    }
    @Test
    public void testGetCount(){
        Hero hero1 = new Hero("Ivan", 3);
        Hero hero2 = new Hero("Pesho", 1);
        Hero hero3 = new Hero("Tosho", 4);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        heroRepository.create(hero2);
        heroRepository.create(hero3);
        Assert.assertEquals(heroRepository.getCount(), 3);
    }
    @Test(expected = NullPointerException.class)
    public void testCreateHeroWithException(){
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(null);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testCreateHeroWithExistingHero(){
        Hero hero1 = new Hero("Ivan", 3);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        heroRepository.create(hero1);
    }
    @Test(expected = NullPointerException.class)
    public void testRemoveHeroWithNullException(){
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.remove(null);


    }
    @Test
    public void testRemoveCorrect(){
        Hero hero1 = new Hero("Ivan", 3);
        Hero hero2 = new Hero("Pesho", 1);
        Hero hero3 = new Hero("Tosho", 4);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        heroRepository.create(hero2);
        heroRepository.create(hero3);
        Assert.assertTrue(heroRepository.remove("Ivan"));
    }
    @Test
    public void testGetHeroWithHighestLevel(){
        Hero hero1 = new Hero("Ivan", 3);
        Hero hero2 = new Hero("Pesho", 1);
        Hero hero3 = new Hero("Tosho", 4);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        heroRepository.create(hero2);
        heroRepository.create(hero3);
        Hero hero = heroRepository.getHeroWithHighestLevel();
        Assert.assertEquals(hero.getLevel(), hero3.getLevel());
        Assert.assertEquals(hero.getName(), hero3.getName());
    }
    @Test
    public void testGetHero(){
        Hero hero1 = new Hero("Ivan", 3);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        Hero hero = heroRepository.getHero("Ivan");
        Assert.assertEquals(hero.getName(), "Ivan");
    }
    @Test
    public void testGetHeroes(){
        Hero hero1 = new Hero("Ivan", 3);
        Hero hero2 = new Hero("Pesho", 1);
        Hero hero3 = new Hero("Tosho", 4);
        HeroRepository heroRepository = new HeroRepository();
        heroRepository.create(hero1);
        heroRepository.create(hero2);
        heroRepository.create(hero3);
        Collection<Hero> heroes = heroRepository.getHeroes();
        Assert.assertEquals(heroes.size(), heroRepository.getCount());
    }
}
