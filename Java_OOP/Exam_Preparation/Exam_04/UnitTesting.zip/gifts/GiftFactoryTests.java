package gifts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.security.Key;
import java.util.Collection;
import java.util.List;

public class GiftFactoryTests {
    @Test
    public void testCreateGiftCorrect(){
        Gift gift = new Gift("Key", 5);
        GiftFactory giftFactory = new GiftFactory();
        giftFactory.createGift(gift);
        Assert.assertEquals(giftFactory.getCount(), 1);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testCreateGiftWithExistingGift(){
        Gift gift = new Gift("Key", 5);
        GiftFactory giftFactory = new GiftFactory();
        giftFactory.createGift(gift);
        giftFactory.createGift(gift);
    }
    @Test
    public void testRemoveGiftCorrect(){
            Gift gift = new Gift("Key", 5);
            GiftFactory giftFactory = new GiftFactory();
            giftFactory.createGift(gift);
            giftFactory.removeGift("Key");
            Assert.assertEquals(giftFactory.getCount(), 0);

    }
    @Test(expected = NullPointerException.class)
    public void testRemoveGiftWithException(){
        GiftFactory giftFactory = new GiftFactory();
        giftFactory.removeGift(null);
    }
    @Test
    public void testGetPresentWithLeastMagic(){
            Gift gift = new Gift("Key", 5);
            Gift gift1 = new Gift("Car", 8);
            GiftFactory giftFactory = new GiftFactory();
            giftFactory.createGift(gift);
            giftFactory.createGift(gift1);
            Gift giftLeastMagic = giftFactory.getPresentWithLeastMagic();
            Assert.assertEquals(giftLeastMagic.getMagic(), 5,0);

    }
    @Test
    public void testGetPresent(){
        Gift gift = new Gift("Key", 5);
        Gift gift1 = new Gift("Car", 8);
        GiftFactory giftFactory = new GiftFactory();
        giftFactory.createGift(gift);
        giftFactory.createGift(gift1);
        Gift presentByName = giftFactory.getPresent("Key");
        Assert.assertEquals(presentByName.getType(), "Key");
    }
    @Test
    public void testGetPresents(){
        Gift gift = new Gift("Key", 5);
        Gift gift1 = new Gift("Car", 8);
        GiftFactory giftFactory = new GiftFactory();
        giftFactory.createGift(gift);
        giftFactory.createGift(gift1);
        Collection<Gift> presents = giftFactory.getPresents();
        Gift giftFound = presents.stream().filter(p-> p.getType().equals("Car")).findFirst().get();
        Assert.assertEquals(giftFound.getType(), "Car");
    }

}
