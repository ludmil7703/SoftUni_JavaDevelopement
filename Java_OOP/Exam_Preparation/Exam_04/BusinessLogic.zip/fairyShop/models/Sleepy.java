package fairyShop.models;

public class Sleepy extends BaseHelper{
    private static final int SLEEPY_INITIAL_ENERGY = 50;

    public Sleepy(String name) {
        super(name, SLEEPY_INITIAL_ENERGY);
    }
    @Override
    public void work() {
        setEnergy(Math.max(getEnergy() - 15, 0));
    }
}
