package fairyShop.models;

public class Happy extends BaseHelper{
    private static final int HAPPY_INITIAL_ENERGY = 100;

    public Happy(String name) {
        super(name, HAPPY_INITIAL_ENERGY);
    }
    @Override
    public void work() {
        setEnergy(Math.max(getEnergy() - 10, 0));
    }
}
