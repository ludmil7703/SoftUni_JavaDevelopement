package fairyShop.models;

public class ShopImpl implements Shop{
    public ShopImpl() {
    }

    @Override
    public void craft(Present present, Helper helper) {

    }
}
