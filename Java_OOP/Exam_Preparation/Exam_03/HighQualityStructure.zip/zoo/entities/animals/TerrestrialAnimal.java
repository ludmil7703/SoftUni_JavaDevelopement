package zoo.entities.animals;

public class TerrestrialAnimal extends BaseAnimal{
    private static final double TERRESTRIAL_INITIAL_KILOGRAMS = 5.50;
    private static final double TERRESTRIAL_INCREASE_KILOGRAMS = 5.70;

    public TerrestrialAnimal(String name, String kind, double price) {
        super(name, kind, TERRESTRIAL_INITIAL_KILOGRAMS, price);
    }

    @Override
    public void eat() {
        setKg(getKg() + TERRESTRIAL_INCREASE_KILOGRAMS);
    }
}
