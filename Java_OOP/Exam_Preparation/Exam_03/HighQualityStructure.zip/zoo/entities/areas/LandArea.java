package zoo.entities.areas;

public class LandArea extends BaseArea{
    private final static int LAND_AREA_CAPACITY = 25;

    public LandArea(String name) {
        super(name, LAND_AREA_CAPACITY);
    }
}
