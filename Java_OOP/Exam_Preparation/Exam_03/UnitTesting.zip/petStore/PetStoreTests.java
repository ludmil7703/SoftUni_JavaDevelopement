package petStore;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class PetStoreTests {

    @Test
    public void testGetAnimals(){
        PetStore petStore = new PetStore();
        petStoreFill(petStore);
        String nameActual = petStore.getAnimals().get(0).getSpecie();
        double priceActual = petStore.getAnimals().get(0).getPrice();
        String nameExpected = "Koko";
        double priceExpected = 20;
        Assert.assertEquals(nameActual, nameExpected);
        Assert.assertEquals(priceActual, priceExpected, 0);


    }
    @Test
    public void testGetCount(){
        PetStore petStore = new PetStore();
        petStoreFill(petStore);
        Assert.assertEquals(petStore.getCount(), 2);
    }
    @Test
    public void testFindAllAnimalsWithMaxKilograms(){
        PetStore petStore = new PetStore();
        petStoreFill(petStore);
        List<Animal> animals = petStore.findAllAnimalsWithMaxKilograms(3);
        Assert.assertEquals(animals.get(0).getMaxKilograms(), 5);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testAddAnimalWithNullArgs(){
        PetStore petStore = new PetStore();
        petStore.addAnimal(null);
    }
    @Test
    public void testGetTheMostExpensiveAnimal(){
        PetStore petStore = new PetStore();
        petStoreFill(petStore);
        Animal animal = petStore.getTheMostExpensiveAnimal();
        Assert.assertEquals(animal.getPrice(), 50, 0);
    }
    @Test
    public void testFindAllAnimalBySpecies(){
        PetStore petStore = new PetStore();
        petStoreFill(petStore);
        List<Animal> animals = petStore.findAllAnimalBySpecie("Dog");
        Assert.assertEquals(animals.get(0).getSpecie(), "Dog");
    }
    @Test
    public void testGetAge(){
        Animal animal = new Animal("Dog", 10, 50);
        animal.setAge(2);
        Assert.assertEquals(animal.getAge(), 2);
    }

    private void petStoreFill(PetStore petStore) {
        Animal animal1 = new Animal("Koko", 2, 20);
        Animal animal2 = new Animal("Dog", 5, 50);
        petStore.addAnimal(animal1);
        petStore.addAnimal(animal2);
    }

}

