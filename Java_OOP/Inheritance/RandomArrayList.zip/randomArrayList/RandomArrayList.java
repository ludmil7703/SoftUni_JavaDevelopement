package randomArrayList;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class RandomArrayList<T> extends ArrayList {
    public Object getRandomElement(){
        int index = ThreadLocalRandom.current().nextInt(0, size());
        return get(index);
    }
}
