import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;


public class Main {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class reflectionClass = Reflection.class;

        Method[] methods = reflectionClass.getDeclaredMethods();
        Field[] fields = reflectionClass.getDeclaredFields();
      Comparator<Method> comparator = Comparator.comparing(Method::getName);
      Comparator<Field> comparatorField = Comparator.comparing(Field::getName);
        Set<Method> getters = new TreeSet<>(comparator);
        Set<Method> setters = new TreeSet<>(comparator);
        Set<Field> fieldSet = new TreeSet<>(comparatorField);

        for (Method method : methods) {
            String methodName = method.getName();
            if (methodName.contains("get")){
                getters.add(method);

            }else if (methodName.contains("set")){
                setters.add(method);
            }
        }
        fieldSet.addAll(Arrays.asList(fields));

        for (Field field : fieldSet) {

            int modifier = field.getModifiers();
            if (!Modifier.isPrivate(modifier)) {
                System.out.println(field.getName() + " must be private!");

            }
        }
        for (Method getter : getters) {

            int modifier = getter.getModifiers();
            if (!Modifier.isPublic(modifier)){
                System.out.println(getter.getName() + " have to be public!");

            }
        }

        for (Method setter : setters) {
            int modifier = setter.getModifiers();
            if (!Modifier.isPrivate(modifier)){
                System.out.println(setter.getName() + " have to be private!");

            }
        }
    }
}
