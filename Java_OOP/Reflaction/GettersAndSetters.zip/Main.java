import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;


public class Main {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class reflectionClass = Reflection.class;

        Method[] methods = reflectionClass.getDeclaredMethods();
      Comparator<Method> comparator = Comparator.comparing(Method::getName);
        Set<Method> getters = new TreeSet<>(comparator);
        Set<Method> setters = new TreeSet<>(comparator);

        for (Method method : methods) {
            String methodName = method.getName();
            if (methodName.contains("get")){
                getters.add(method);

            }else if (methodName.contains("set")){
                setters.add(method);
            }
        }

        for (Method getter : getters) {

                System.out.println(getter.getName() + " will return class " + getter.getReturnType().getName());
            }

        for (Method setter : setters) {
            System.out.println(setter.getName() + " and will set field of class " + setter.getParameterTypes()[0].getName());
        }
    }
}
